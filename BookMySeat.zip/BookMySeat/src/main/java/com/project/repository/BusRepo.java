package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import com.project.model.Bus;

public interface BusRepo extends JpaRepository<Bus, Integer> {
    
    // Custom query to select buses with capacity >= 0
	 @Query("SELECT b FROM Bus b WHERE b.capacity > 0 AND b.date >= CURRENT_DATE")
	    List<Bus> findAvailableBuses();
}
