package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.model.Ticket;


public interface TicketRepo extends JpaRepository<Ticket, Integer> {
	
			List<Ticket> findByBusNumber(String busNumber);
			
			List<Ticket> findByUserName(String userName);
			
			@Query("SELECT count(t) FROM Ticket t WHERE t.userName = :userName")
			int findByUserNamecount(String userName);
			
			@Query("SELECT t FROM Ticket t WHERE t.userName = :userName AND t.date >= CURRENT_DATE")
			List<Ticket> findByUserNameAndDateFromToday(@Param("userName") String userName);
			
			@Query("SELECT t FROM Ticket t WHERE t.userName = :userName AND t.busName = :busName AND t.date >= CURRENT_DATE")
			List<Ticket> findByUserNameBusNameAndDateFromToday(@Param("userName") String userName, @Param("busName") String busName);

			
			@Query("SELECT count(t) FROM Ticket t WHERE t.userName = :userName AND t.date >= CURRENT_DATE")
			long findByUserNameAndDateFromToday1(@Param("userName") String userName);

}
