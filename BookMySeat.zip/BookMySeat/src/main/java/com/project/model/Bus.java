package com.project.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Bus {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String busNumber;
	private String busName;
	private String fromCity;
	private String toCity;
	private String date;
	private String time;
	private int capacity;
	private int  prize;
	private String busImage;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBusNumber() {
		return busNumber;
	}
	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getFromCity() {
		return fromCity;
	}
	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}
	public String getToCity() {
		return toCity;
	}
	public void setToCity(String toCity) {
		this.toCity = toCity;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int getPrize() {
		return prize;
	}
	public void setPrize(int prize) {
		this.prize = prize;
	}
	public String getBusImage() {
		return busImage;
	}
	public void setBusImage(String busImage) {
		this.busImage = busImage;
	}
	public Bus(String busNumber, String busName, String fromCity, String toCity, String date, String time,
			int capacity, int prize, String busImage) {
		super();
		this.busNumber = busNumber;
		this.busName = busName;
		this.fromCity = fromCity;
		this.toCity = toCity;
		this.date = date;
		this.time = time;
		this.capacity = capacity;
		this.prize = prize;
		this.busImage = busImage;
	}
	public Bus() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Bus [id=" + id + ", busNumber=" + busNumber + ", busName=" + busName + ", fromCity=" + fromCity
				+ ", toCity=" + toCity + ", Date=" + date + ", time=" + time + ", capacity=" + capacity + ", prize="
				+ prize + ", busImage=" + busImage + "]";
	}
	
	
	

}
