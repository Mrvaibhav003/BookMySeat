package com.project.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Ticket {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String busNumber;
	private String busName;
	private String fromCity;
	private String toCity;
	private String date;
	private String time;
	private int  prize;
	private int  tPrize;
	private int tSeat;
	private String userName;
	private String email;
	private String Number;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBusNumber() {
		return busNumber;
	}
	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getFromCity() {
		return fromCity;
	}
	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}
	public String getToCity() {
		return toCity;
	}
	public void setToCity(String toCity) {
		this.toCity = toCity;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getPrize() {
		return prize;
	}
	public void setPrize(int prize) {
		this.prize = prize;
	}
	public int gettPrize() {
		return tPrize;
	}
	public void settPrize(int tPrize) {
		this.tPrize = tPrize;
	}
	public int gettSeat() {
		return tSeat;
	}
	public void settSeat(int tSeat) {
		this.tSeat = tSeat;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNumber() {
		return Number;
	}
	public void setNumber(String number) {
		Number = number;
	}
	public Ticket(int id, String busNumber, String busName, String fromCity, String toCity, String date, String time,
			int prize, int tPrize, int tSeat, String userName, String email, String number) {
		super();
		this.id = id;
		this.busNumber = busNumber;
		this.busName = busName;
		this.fromCity = fromCity;
		this.toCity = toCity;
		this.date = date;
		this.time = time;
		this.prize = prize;
		this.tPrize = tPrize;
		this.tSeat = tSeat;
		this.userName = userName;
		this.email = email;
		Number = number;
	}
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Ticket [id=" + id + ", busNumber=" + busNumber + ", busName=" + busName + ", fromCity=" + fromCity
				+ ", toCity=" + toCity + ", date=" + date + ", time=" + time + ", prize=" + prize + ", tPrize=" + tPrize
				+ ", tSeat=" + tSeat + ", userName=" + userName + ", email=" + email + ", Number=" + Number + "]";
	}
	
	
	

}
