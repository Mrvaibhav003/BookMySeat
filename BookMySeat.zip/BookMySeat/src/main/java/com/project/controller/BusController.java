package com.project.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.project.model.Bus;
import com.project.model.Ticket;
import com.project.repository.BusRepo;
import com.project.repository.TicketRepo;

@Controller
public class BusController {
	
	@Autowired
		BusRepo br;
	
	@Autowired
	TicketRepo tr;
	
	
	@RequestMapping("/addbusdetails")
	public String addBusDetails(
	        @RequestParam String busNumber,
	        @RequestParam String busName,
	        @RequestParam String fromCity,
	        @RequestParam String toCity,
	        @RequestParam String date, 
	        @RequestParam String time, 
	        @RequestParam int capacity, 
	        @RequestParam int prize,
	        @RequestParam("busImage") MultipartFile busImage) {
	    
	 
	    Bus ob = new Bus();
	    ob.setBusNumber(busNumber);
	    ob.setBusName(busName);
	    ob.setFromCity(fromCity);
	    ob.setToCity(toCity);
	    ob.setDate(date); 
	    ob.setTime(time);
	    ob.setCapacity(capacity); 
	    ob.setPrize(prize); 

	    // Handle file upload
	    if (!busImage.isEmpty()) {
	        try {
	         
	            String imagePath = saveBusImage(busImage); 
	            ob.setBusImage(imagePath);
	        } catch (Exception e) {
	            
	        }
	    }
	    
	    // Save the Bus object to the database
	    br.save(ob);
	  
	    
	    return "busdetails.jsp?message='Bus Added Successful'"; // Assuming you want to redirect to the admin dashboard
	}
	private static final String UPLOAD_DIR = "C:\\Users\\chand\\Documents\\pw_from_july\\BookMySeat\\src\\main\\webapp\\images\\";
	
	private String saveBusImage(MultipartFile busImage) throws IOException {
	    // Define the directory where the images will be saved
	    String fileName = busImage.getOriginalFilename();
	    Path filePath = Paths.get(UPLOAD_DIR, fileName);
	    
	    // Save the file to the specified directory
	    Files.copy(busImage.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
	    
	    // Return the file path for storage in the database (you might want to return a relative path)
	    return fileName; // or return filePath.toString(); depending on your requirement
	}

	
	@RequestMapping("/showbusdetails")
	public String ShowBusdetails(Model m,HttpSession session)
	{
		List<Bus> al=br.findAll();
		
		m.addAttribute("bus",al);
		
		
		return "showbusdetails.jsp";
		
	}
	@RequestMapping("/deletebusdetails/{id}")
	public String  DeleteBusDetails(@PathVariable int id)
	{
		br.deleteById(id);
		
		return "redirect:/showbusdetails";
	}
	
	@RequestMapping("/updatinfo")
	public String  updateDetails1(@RequestParam int id,Model m)
	{
		Bus ob=br.findById(id).orElse(null);
		m.addAttribute("update", ob);
		
		return "busupdate.jsp";
	}
	
	@RequestMapping("/editbus")
	public String EditBus(  @RequestParam String busNumber,
	        @RequestParam String busName,
	        @RequestParam String fromCity,
	        @RequestParam String toCity,
	        @RequestParam String date, 
	        @RequestParam String time, 
	        @RequestParam int capacity, 
	        @RequestParam int prize,
	        @RequestParam int id,
	        @RequestParam("busImage") MultipartFile busImage) {
		
		
		 Bus ob = br.findById(id).orElse(null);
		    ob.setBusNumber(busNumber);
		    ob.setBusName(busName);
		    ob.setFromCity(fromCity);
		    ob.setToCity(toCity);
		    ob.setDate(date); 
		    ob.setTime(time);
		    ob.setCapacity(capacity); 
		    ob.setPrize(prize); 
		
		if (!busImage.isEmpty()) {
	        try {
	         
	            String imagePath = BusImage(busImage); 
	            ob.setBusImage(imagePath);
	        } catch (Exception e) {
	            
	        }
	    }
		
		  br.save(ob);
		  
		  return "redirect:/showbusdetails";
	}
private static final String UPLOAD_DIR1 = "C:\\Users\\chand\\Documents\\pw_from_july\\BookMySeat\\src\\main\\webapp\\images\\";
	
	private String BusImage(MultipartFile busImage) throws IOException {
	    // Define the directory where the images will be saved
	    String fileName = busImage.getOriginalFilename();
	    Path filePath = Paths.get(UPLOAD_DIR1, fileName);
	    
	    // Save the file to the specified directory
	    Files.copy(busImage.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
	    
	    // Return the file path for storage in the database (you might want to return a relative path)
	    return fileName; // or return filePath.toString(); depending on your requirement
	}
	
	@RequestMapping("/showbus")
	public String ShowBus(Model m,@RequestParam String msg)
	{
		
		List<Bus> al=br.findAvailableBuses();
		
		m.addAttribute("show",al);
		
		return "showbus.jsp?msg='"+msg+"'";
	}
	
	@RequestMapping("/bookbus")
	public String Book(@RequestParam int id,@RequestParam int tseat,HttpSession s,Model m, @RequestParam String msg)
	{
		Bus ob=br.findById(id).orElse(null);
		
		Ticket tbj=new Ticket();
		
		if(ob.getCapacity()>=tseat)
		{
			
		tbj.setBusName(ob.getBusName());
		tbj.setBusNumber(ob.getBusNumber());
		tbj.setDate(ob.getDate());
		tbj.setTime(ob.getTime());
		tbj.setFromCity(ob.getFromCity());
		tbj.setToCity(ob.getToCity());
		tbj.settSeat(tseat);
		tbj.settPrize(tseat*ob.getPrize());
		tbj.setPrize(ob.getPrize());
		tbj.setUserName(s.getAttribute("username").toString());
		tbj.setNumber(s.getAttribute("number").toString());
		tbj.setEmail(s.getAttribute("email").toString());
		
		ob.setCapacity(ob.getCapacity()-tseat);
		br.save(ob);
		tr.save(tbj);
		
		return"redirect:/showbus?msg="+msg;
		
		}
		else
		{
			
			return"redirect:/showbus";
		}
		
	}
	@RequestMapping("/checkticket")
	public String CheckTicket(Model m)
	{
		List<Bus> al=br.findAll();
		
		m.addAttribute("chekkey",al);
		
		return "checkticket.jsp";
	}
	
	@RequestMapping("/showtickets")
	public String ShowTickets(@RequestParam String busNumber,Model m)
	{
		List<Ticket> al=tr.findByBusNumber(busNumber);
		
		m.addAttribute("ticket",al);
		
		return"showticket.jsp";
		
	}
	
	
	@RequestMapping("/bookedticket")
	public String BookedTicket(@RequestParam String username,Model m)
	{
		List<Ticket> al=tr.findByUserNameAndDateFromToday(username);
		
		m.addAttribute("bticket",al);
		
		
		
		return "bookedticket.jsp";
	}
	
	@RequestMapping("/viewticket")
	public String ViewTicket(@RequestParam int id,Model m)
	{
		Ticket tk=tr.findById(id).orElse(null);
		
		
		m.addAttribute("x",tk);
		
		return "viewticket.jsp";
	}
	
	@RequestMapping("/cancleticket")
	public String Cancle(@RequestParam int id,Model m)
	{
		tr.deleteById(id);
		m.addAttribute("msg", "Ticket Cancle Successfull");
		return "userdashbord.jsp";
	}
	
	@RequestMapping("/mytickets")
	public String MyTickets(@RequestParam String username, Model m)
	{
		List<Ticket> al=tr.findByUserName(username);
		
		m.addAttribute("myticket",al);
		return "myticket.jsp";
	}

}
