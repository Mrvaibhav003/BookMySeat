package com.project.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Admin;
import com.project.repository.AdminRepo;
import com.project.repository.BusRepo;
import com.project.repository.TicketRepo;
import com.project.repository.UserRepo;
@Controller
public class AdminController {
	
	@Autowired
	AdminRepo ar;
	
	@Autowired
	UserRepo ur;
	
	@Autowired
	BusRepo br;
	
	@Autowired
	TicketRepo tr;
	
	@RequestMapping("/checkadminlogin")
	public String CheckAdminLogin(@RequestParam String email,String password,HttpSession session)
	{
	
		Admin ob=ar.findByEmail(email);
		
		session.setAttribute("usercount", ur.count());
		session.setAttribute("buscount", br.count());
		session.setAttribute("allticket",tr.count());
		
		if(ob!=null && email.equals(ob.getEmail())&&password.equalsIgnoreCase(ob.getPassword()))
		{
			return "admindashbord.jsp";
		}
		else
		{
			return"adminlogin.jsp";
		}
	}

}
