package com.project.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.model.User;
import com.project.repository.TicketRepo;
import com.project.repository.UserRepo;

@Controller
public class UserController {
	
	@Autowired
	UserRepo ur;
	@Autowired
	TicketRepo tr;
	
	@RequestMapping("/")
	public String  Home()
	{
		return "index.jsp";
	}
	
	@RequestMapping("/userlogin")
	public String UserLogin(@ModelAttribute User ob,@RequestParam String email)
	{
			User obj=ur.findByEmail(email);
		if(obj!=null)
		{
			return "index.jsp?message='This Email Already Exist'";
		}
		else
		{
		ur.save(ob);		

		return "userlogin.jsp?message='Registration Successful'";
		
		}
	}
	
	@RequestMapping("/checkuserlogin")
	public String CheckUserLogin(@RequestParam String email,@RequestParam String password,HttpSession session)
	{
		
		User ob=ur.findByEmail(email);
		
		if(ob!=null && email.equals(ob.getEmail())&&password.equalsIgnoreCase(ob.getPassword()))
		{
			session.setAttribute("username", ob.getName());
			session.setAttribute("number", ob.getNumber());
			session.setAttribute("email", ob.getEmail());
			session.setAttribute("bookt", tr.findByUserNameAndDateFromToday1(ob.getName()));
			
			session.setAttribute("myticket",tr.findByUserNamecount(ob.getName()));
			return "userdashbord.jsp";
		}
		else
		{
			return "userlogin.jsp?message='Login fail'";
		}
	}
	
	@RequestMapping("/showuserdetails")
	public String ShowUserDetails(Model m)
	{
		List<User> al=ur.findAll();
		m.addAttribute("data", al);
		
		return "/userdetails.jsp";
		
	}
	
	@RequestMapping("/deleteuser/{id}")
	public String DeleteUser(@PathVariable int  id)
	{
		ur.deleteById(id);
		return "redirect:/showuserdetails";
		
	}

}
